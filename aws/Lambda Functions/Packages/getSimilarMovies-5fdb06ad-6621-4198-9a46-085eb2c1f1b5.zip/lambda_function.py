import json
import requests 
import time
import lxml
from bs4 import BeautifulSoup

def removePunct(the_str):
    punct = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
    for character in the_str:
        if character in punct:
            the_str = the_str.replace(character, "")
    return the_str

def searchIncomplete(title):
    moviestr = removePunct(title)
    words = moviestr.split(" ")
    search_url = "https://www.imdb.com/find?q="
    for i in range(len(words)):
        search_url = search_url + words[i]
        if i != len(words)-1:
            search_url = search_url+"+"
    # print(search_url)
    page = requests.get(search_url)
    
    content = page.content
    soup = BeautifulSoup(content,"lxml")
    movieResults = soup.find('td', class_="result_text")
    fullTitle = movieResults.find('a')
    # print(fullTitle.text)
    return fullTitle.text

def lambda_handler(event, context):
    #print(event)
    data = json.loads(event['body'])
    movieTitle = data['title']
    # print(movieTitle)
    # movieTitle = event["title"]
    words = movieTitle.split(" ")
    
    search_url = "https://www.google.com/search?q=movies+like+"
    
    for i in range(len(words)):
        search_url = search_url + words[i]
        if i != len(words)-1:
            search_url = search_url+"+"

    page = requests.get(search_url)

    content = page.content
    soup = BeautifulSoup(content[0:len(content)//5],"lxml")
    
    try:
        textBoxes = soup.findAll('div', class_="BNeawe s3v9rd AP7Wnd")
        index = 0
        ls = []
        while "·" not in textBoxes[index].text and index < len(textBoxes):
            title = textBoxes[index].text
            if title[-3:] == "...":
                print(title)
                title = searchIncomplete(title[:-3])
            if title not in ls:
                ls.append(title)
            index = index + 1
        # print(ls)
        return {
            'statusCode': 200,
            'body': json.dumps(ls)
        }
    except:
        print("An exception occurred")
