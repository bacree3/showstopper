var chromium = require('chrome-aws-lambda');

exports.handler = async function(event, context, callback){
  let result = 'result';
  let browser;

  try {
    browser = await chromium.puppeteer.launch({
      args: chromium.args,
      defaultViewport: chromium.defaultViewport,
      executablePath: await chromium.executablePath,
      headless: chromium.headless,
      ignoreHTTPSErrors: true,
    });
    
    if (!event) {
        return Promise.resolve();
    }
    var json = JSON.parse(event.body);
    var title = json.title;

    title = title.replace(/[^\w\s]/g, " ");
    
    var titleWords = title.split(" ");
    var searchURL = 'https://www.google.com/search?q=';

    for (var i = 0; i < titleWords.length; i++) {
      if (titleWords[i].length > 0) {
        searchURL = searchURL + titleWords[i];
        if (i != titleWords.length - 1) {
          searchURL = searchURL + "+";
        }
      }
      
    }
    //searchURL = searchURL + "+movie";
    console.log(searchURL);
    
    
    const page = await browser.newPage();
    
    // console.log(`Navigating to ${this.url}...`);
    await page.goto(searchURL);
    
    await page.waitForSelector('div.ellip.bclEt');

    const platformsList = await page.evaluate(function () {
        let container = document.querySelector("div[jsname='gI9xcc']")
        const links = container.querySelectorAll("a")
        var num = 0
        var platforms = []
        for (var i = 0; i < links.length; i++) {
            if (links[i].href != null) {
                num = num + 1
                var link = links[i].href
                var name = links[i].querySelector("div.ellip.bclEt").textContent
                // var str = "{ name: " + name + ", link: " + link + " }"
                var str = {id: i, name: name, link: link};
                platforms.push(str)
            }
        }
        return platforms;
    })

    console.log(platformsList)
    result = JSON.stringify(platformsList)

  } catch (error) {
    return callback(error);
  } finally {
    if (browser !== null) {
      await browser.close();
    }
  }

  return callback(null, result);
};