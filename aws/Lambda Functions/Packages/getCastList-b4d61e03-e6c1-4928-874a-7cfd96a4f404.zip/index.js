var chromium = require('chrome-aws-lambda');

exports.handler = async function(event, context, callback){
  let result = 'result';
  let browser;

  try {
    browser = await chromium.puppeteer.launch({
      args: chromium.args,
      defaultViewport: chromium.defaultViewport,
      executablePath: await chromium.executablePath,
      headless: chromium.headless,
      ignoreHTTPSErrors: true,
    });
    if (!event) {
        return Promise.resolve();
    }
    var json = JSON.parse(event.body);
    console.log(json);
    var title = json.title;
    // var title = event.title

    var titleWords = title.split(" ");
    var searchURL = 'https://www.google.com/search?q=';

    for (var i = 0; i < titleWords.length; i++) {
      searchURL = searchURL + titleWords[i];
      if (i != titleWords.length - 1) {
        searchURL = searchURL + "+";
      }
    }
    
    searchURL = searchURL + "+cast";
    
    console.log(searchURL);
    
    const page = await browser.newPage();
    
    // console.log(`Navigating to ${this.url}...`);
    await page.goto(searchURL);
    
    // await page.waitForSelector('div.fl.ellip.oBrLN.S1gFKb.rOVRL');
    await page.waitForSelector('div.FozYP')

    const castList = await page.evaluate(function () {
        // let container = document.querySelector("div[jsname='gI9xcc']")
        let container = document.querySelector("div.EDblX.DAVP1")
        const actors = container.querySelectorAll("a")
        var num = 0
        var cast = []
        for (var i = 0; i < actors.length; i++) {
            // let name = actors[i].aria-label
            if (actors[i].textContent != ''){
                let name = ''
                let nameParts = actors[i].querySelectorAll("div[jsname='T3JDGc']")
                for (var j = 0; j < nameParts.length; j++) {
                    if (j == 0) {
                        name = nameParts[j].textContent
                    } else {
                        name = name + " " + nameParts[j].textContent
                    }
                }
                cast.push(name)
            }
        }
        return cast;
    })

    console.log(castList)
    result = JSON.stringify(castList)

  } catch (error) {
    return callback(error);
  } finally {
    if (browser !== null) {
      await browser.close();
    }
  }

  return callback(null, result);
};