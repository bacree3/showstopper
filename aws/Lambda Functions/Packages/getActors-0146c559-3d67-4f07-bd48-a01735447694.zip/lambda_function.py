import json
import requests 
from bs4 import BeautifulSoup

def lambda_handler(event, context):
    #print(event)
    data = json.loads(event['body'])
    movieID = data['id']
    print(movieID)
    # movieID = event["ID"]
    
    # TODO implement
    search_url = "https://www.imdb.com/title/" + movieID

    # page = requests.get("https://www.imdb.com/title/tt0848228")
    page = requests.get(search_url)

    content = page.content
    soup = BeautifulSoup(content,"html.parser")
    actorsTable = soup.find("table", class_="cast_list")
    
    try:
        actors = actorsTable.findAll('td', class_=lambda x: x!="primary_photo" and x!="ellipsis" and x!="character")
        ls = []
        for i in range(len(actors)):
            name = actors[i].find('a')
            if name is not None:
                ls.append(name.text[1:-1])
        # print(ls)
        return {
            'statusCode': 200,
            'body': json.dumps(ls)
        }
    except:
        print("An exception occurred")


    
